def inbetween(n: int, a: int, b: int) -> bool:
    return n >= a and n <= b