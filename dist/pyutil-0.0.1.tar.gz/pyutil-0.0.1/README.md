# pyutil
A module containing random useful things